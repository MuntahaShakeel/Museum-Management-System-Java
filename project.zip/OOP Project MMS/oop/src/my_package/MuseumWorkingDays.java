
package my_package;
public enum MuseumWorkingDays {
	SATURDAY , SUNDAY , MONDAY , TUESDAY , WEDNESDAY , THURSDAY ;
}

