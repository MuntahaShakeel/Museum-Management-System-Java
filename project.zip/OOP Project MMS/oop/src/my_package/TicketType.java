
package my_package;
public enum TicketType {
    ONE_TIME,
    MULTI_TIME_WEEKLY,
    MULTI_TIME_MONTHLY
}