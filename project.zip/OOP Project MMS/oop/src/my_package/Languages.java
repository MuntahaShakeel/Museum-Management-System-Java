
package my_package;
public enum Languages {
	ARABIC , ENGLISH , FRENCH , SPANISH;

}
